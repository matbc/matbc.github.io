%% X is of n*p with n >= 2*p. All the columns of X is normalied
%% requires CVX active
function Xtilde = knockoffCreate(X)
%require normalized columns!!!
if abs(norm(X(:,1),2)-1)>1e-6 error('Columns must be normalized!'); end
Sigma = X'*X;
[~, p] = size(X);

cvx_begin quiet
%    cvx_precision best
%    cvx_precision high
    variable s(p);
    maximize(sum(s))
    2*Sigma-diag(s) == semidefinite(p);
    0 <= s <= 1
cvx_end

A = 2*diag(s) - diag(s)/Sigma*diag(s);
C = chol(A);

[U, ~, ~] = svd(X);
Utilde = U(:, p+1:2*p);

Xtilde = X*(eye(p) - Sigma\diag(s)) + Utilde*C;

return

