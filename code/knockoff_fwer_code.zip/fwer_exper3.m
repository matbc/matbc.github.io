% requires CVX, lars3, MTStepdown, MTStepup, MTknockoff, MTHolm, knockoffCreate, kthvalue
tic

RandStream.setGlobalStream(RandStream('mt19937ar','seed', 1000*run));
seed = RandStream.getGlobalStream.Seed;

cd cvx
cvx_setup;
cd ..

version_num = 7;
load(['paramsFWER' num2str(version_num) '.mat'])

if params(1,end) ~= version_num, error('params file doesnt match version'); end
dir = ['../results/FWER' num2str(version_num) '/'];

m = params(run,1);
n = params(run,2);
p = n*params(run,3);
sig2 = params(run,4);
alpha = params(run,5);
k = params(run,6);
modified = logical(params(run,7));
mag = params(run,8);
false_ind = 1:round(p*params(run,9));
nsim = params(run,10);
version = params(run,11);

new = true;
add = false;

if add && new, error('cannot add to results with new design matrix'); end
if add, pow_temp = pow; fwe_temp = fwe; end;

if new
    X = normrnd(0,1,n,p);
    for i = 1:size(X,2), X(:,i) = X(:,i)/norm(X(:,i),2); end
    tic
    Xk = knockoffCreate(X);
    toc
    cov = inv(X'*X);
    cor = cov ./ (sqrt(diag(cov)) * sqrt(diag(cov))');
end

b = zeros(p, 1); b(false_ind) = mag;

v = find(nbininv(1-alpha, 1:20, 1/2) < k, 1, 'last');
fprintf(['v = ' num2str(v) ', ' num2str(k) '-FWER <= ' num2str(1-nbincdf(k-1,v,1/2)) '\n'])
if new, threshs = nan(0,p+1); end
a = [ones(k,1)*k/p; k./(p+k-((k+1):p)')]; % eq (13) in RS06
S = nan(p-k+1,1);
for i = k:p, S(i-k+1) = i*a(p-i+k)/k + i*sum((a(p-i+((k+1):i))-a(p-i+((k+1):i)-1))./((k+1):i)'); end
D = max(S);

methods = {'knockoffs', 'holm', 'stepdown', 'stepup'};
pow = nan(m, length(methods));
fwe = nan(m, length(methods));
for i = 1:m
    y = X*b + sqrt(sig2)*normrnd(0,1,n,1);
    
    prob_increase = (alpha-(1-nbincdf(k-1,v,1/2)))/(nbincdf(k-1,v,1/2)-nbincdf(k-1,v+1,1/2));
    if(binornd(1,prob_increase)==1)
        v_rand = v+1;
    else
        v_rand = v;
    end
    rej.knockoffs = MTknockoff(y, X, Xk, v_rand, k, modified);
%    fprintf([num2str(rej.knockoffs) '\n'])
    rej.holm = MTHolm(y, X, sqrt(sig2), alpha, k, modified, cov, false);
    [rej.stepdown, threshs] = MTStepdown(y, X, sqrt(sig2), alpha, k, threshs, nsim, modified, cov, cor, false);
    rej.stepup = MTStepup(y, X, sqrt(sig2), alpha, k, modified, cov, D, false);
    
    for j = 1:length(methods)
        pow(i,j) = sum(ismember(false_ind, rej.(methods{j})))/length(false_ind);
        fwe(i,j) = sum(~ismember(rej.(methods{j}), false_ind));
    end
    runtime = toc;
    if mod(i,floor(m/100)) == 0, fprintf(['Simulation ' num2str(i) ' complete, threshs has ' num2str(size(threshs,1)) ' rows, runtime = ' num2str(runtime) '\n']); end
end
toc

if add, pow = [pow_temp; pow]; fwe = [fwe_temp; fwe]; end

powers = mean(pow, 1);
fwer = mean(fwe >= k, 1);

fprintf([num2str(fwer) '\n'])
fprintf([num2str(repmat(sqrt(alpha*(1-alpha)/size(fwe,1)),1,length(methods))) '\n'])
fprintf([num2str(powers) '\n'])
fprintf([num2str(std(pow)/sqrt(size(pow,1))) '\n'])

toc
runtime = toc - tic;

if ~exist(dir, 'dir'), mkdir(dir); end
save([dir 'kFWER' num2str(run) '_n-' ...
    num2str(n) '_p-' num2str(p) '_k-' num2str(k) '_mag-' num2str(mag) ...
    '_falseinds-' num2str(round(p*params(run,9))) '.mat'], 'methods', ...
    'pow', 'fwe', 'k', 'm', 'alpha', 'runtime', 'seed');
