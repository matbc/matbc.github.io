function R = MTStepup(y, X, sigma, alpha, k, modified, cov, D, knsig)
%% Returns indices of coefficients rejected by stepup procedure of Romano_Shaikh-2006
% using critical values from equation (13), applied to the OLS p-values of y regressed on X.

if nargin < 9, knsig = true; end
if nargin < 7, XtX = X'*X; cov = inv(XtX); end
if nargin < 6, modified = true; end
n = size(X,1);
s = size(X,2); % number of hypotheses in RS06 notation
a = [ones(k,1)*k/s; k./(s+k-((k+1):s)')]; % eq (13) in RS06
if nargin < 8
    S = nan(s-k+1,1);
    for i = k:s, S(i-k+1) = i*a(s-i+k)/k + i*sum((a(s-i+((k+1):i))-a(s-i+((k+1):i)-1))./((k+1):i)'); end
    D = max(S);
end

ols = cov*(X'*y);
z = ols ./ (sigma*sqrt(diag(cov)));
if knsig
    p = 2 - 2*normcdf(abs(z));
else
    sigmahat = sqrt(sum((y-X*ols).^2)/(n-s));
    p = 2 - 2*tcdf(abs(z*sigma/sigmahat),n-s);
end
[p_ord, ind] = sort(p);

crit_vals = alpha*a/D;
thresh = find(p_ord <= crit_vals, 1, 'last');
if modified, thresh = max([thresh (k-1)]); end
R = ind(1:thresh)';
end