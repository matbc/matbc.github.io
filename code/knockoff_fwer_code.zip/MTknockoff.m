function R = MTknockoff(y, X, Xk, v, k, modified)
%% Returns indices of coefficients rejected by Knockoffs k-FWER procedure,
%  where Xk is knockoffs matrix, v is the chosen level
p = size(X,2);
n = size(X,1);

if nargin < 6, modified = true; end

% % begin glmnet version
% nlam = 5000;
% 
% options = glmnetSet();
% options.standardize = false;
% options.intr = false;
% options.standardize_resp = false;
% %options.pmax = 50;
% 
% lambda_max = max(abs([X Xk]'*y))/n;
% lambda_min = lambda_max/(2*1e3);
% 
% success = false;
% while ~success
%     exponents = (0:(nlam-1))/nlam;
%     options.lambda = lambda_max .* (lambda_min/lambda_max).^exponents;
%     fit = glmnet([X Xk],y,[],options);
%     A = nan(2*p, 1);
%     A_tot = A;
%     ind = 1;
%     ind_tot = 1;
%     vhat = 0;
%     for i = 1:length(fit.lambda)
%         vars = find(fit.beta(:,i));
%         new_var = setdiff(vars, A_tot);
%         if isempty(new_var)
%             continue
%         elseif length(new_var) > 1
%             nlam = nlam*5;
%             fprintf(['increasing discretization\n']);
%             break;
%         elseif new_var > p
%             A_tot(ind_tot) = new_var;
%             ind_tot = ind_tot + 1;
%             if ~ismember(new_var-p, A), vhat = vhat + 1; end
%         else
%             A_tot(ind_tot) = new_var;
%             ind_tot = ind_tot + 1;
%             if ~ismember(new_var+p, A_tot)
%                 A(ind) = new_var;
%                 ind = ind + 1;
%             end
%         end
%         if vhat >= v && sum(~isnan(A)) >= k-1, success = true; break; end
%     end
% end
% R = A(~isnan(A))';
% % end glmnet version, begin lars version

% % begin lars3 version
maxvars = floor(p/7);

success = false;
while ~success
    beta = lars3([X Xk], y, 'LASSO', -maxvars);
    A = nan(maxvars, 1);
    A_tot = A;
    ind = 1;
    vhat = 0;
    for i = 2:size(beta,1)
        var = find(beta(i,:));
        new_var = setdiff(var, A_tot);
        A_tot(i-1) = new_var;
        if new_var > p && ~ismember(new_var-p, A), vhat = vhat + 1; fprintf(['-' num2str(new_var-p) ' ']); end
        if new_var <= p && ~ismember(new_var+p, A_tot)
            A(ind) = new_var;
            ind = ind + 1;
            fprintf(['+' num2str(new_var) ' '])
        end
        if vhat >= v && (sum(~isnan(A)) >= k-1 || ~modified)
            success = true;
            break;
        end
        if i == size(beta,1), fprintf(['increasing maxvars\n']); maxvars = maxvars + floor(p/10); end
    end
end
fprintf('\n')
R = A(~isnan(A))';
% % end lars3 version, begin lars version

% [~, A, ~, ~, ~, ~] = lars2([X Xk], y, 'lasso', Inf, false);
% [~, A1] = ismember(1:p, A);
% [~, A2] = ismember((p+1):(2*p), A);
% A3 = sort(A2(A2<A1));
% 
% if numel(A3)>=v
%     thresh = max([A3(v) (k-1)]);
% else
%     thresh = p;
% end
% R = find(A1 <= thresh);
end